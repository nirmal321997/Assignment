package selinium.seliniumproject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class NewTest {
 
	@BeforeSuite
  public void beforeSuite() {

System.out.println("Going to take a suite");  
  }
  
  @BeforeTest
  public void beforeTest() {
	  
	  System.out.println("Testing the suite that match for us");
  }
  
  @BeforeClass
  public void beforeClass() {
	  
	  System.out.println("Checking it suits for our class");
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  
	  System.out.println("paying the bill");
  }
  
  @Test
  public void f() {
	  
	  System.out.println("collecting our suit correctly");
  }
  
  @AfterMethod
  public void afterMethod() {
	  
	  System.out.println("replace with bill");
  }
  
  @AfterClass
  public void afterClass() {
	  
	  System.out.println("Checking the suit returned properly");
  }

  @AfterTest
  public void afterTest() {
	  
	  System.out.println("Arranging the suit in that palce");
  }

  @AfterSuite
  public void afterSuite() {
	  
	  System.out.println("Finally kept in the place ");
  }

}
