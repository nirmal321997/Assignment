package TestAnatations;

import org.testng.annotations.Test;

public class test {
  @Test
  public void f() {
  }
}
